"""Online Python compiler - Flask backend.

POST /api/run  {"code": str, "stdin": str}
  -> {"stdout", "stderr", "returncode", "timed_out", "time_ms"}

Code runs in a separate, isolated Python process with CPU/memory/file/process
limits and a wall-clock timeout. For public hosting, ALSO run this inside the
provided Docker container (see README) - process limits alone are not a full sandbox.
"""
import os
import subprocess
import sys
import tempfile
import time
from collections import defaultdict, deque

from flask import Flask, jsonify, request, send_from_directory

try:
    import resource  # POSIX only
except ImportError:  # Windows
    resource = None

TIMEOUT_SEC = 10
MAX_CODE_CHARS = 50_000
MAX_STDIN_CHARS = 10_000
MAX_OUTPUT_BYTES = 100_000
MEMORY_LIMIT_BYTES = 256 * 1024 * 1024
RATE_LIMIT = 30          # runs ...
RATE_WINDOW_SEC = 60     # ... per minute per IP

app = Flask(__name__, static_folder="static", static_url_path="/static")
_hits = defaultdict(deque)


def _limits():
    """Applied in the child process before the user's code starts."""
    os.setsid()
    if resource is None:
        return
    resource.setrlimit(resource.RLIMIT_CPU, (TIMEOUT_SEC, TIMEOUT_SEC))
    resource.setrlimit(resource.RLIMIT_AS, (MEMORY_LIMIT_BYTES, MEMORY_LIMIT_BYTES))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1_000_000, 1_000_000))
    resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def _rate_limited(ip):
    now = time.time()
    q = _hits[ip]
    while q and now - q[0] > RATE_WINDOW_SEC:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        return True
    q.append(now)
    return False


def _clip(data: bytes) -> str:
    text = data[:MAX_OUTPUT_BYTES].decode("utf-8", errors="replace")
    if len(data) > MAX_OUTPUT_BYTES:
        text += "\n...[output truncated]"
    return text


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.post("/api/run")
def run():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
    if _rate_limited(ip):
        return jsonify(error="Too many runs. Please wait a moment."), 429

    data = request.get_json(silent=True) or {}
    code = data.get("code", "")
    stdin = data.get("stdin", "")
    if not isinstance(code, str) or not isinstance(stdin, str):
        return jsonify(error="Invalid request."), 400
    if len(code) > MAX_CODE_CHARS or len(stdin) > MAX_STDIN_CHARS:
        return jsonify(error="Code or input is too large."), 413

    with tempfile.TemporaryDirectory(prefix="pyrun_") as workdir:
        path = os.path.join(workdir, "main.py")
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)

        env = {"PATH": "/usr/bin:/bin", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"}
        start = time.perf_counter()
        timed_out = False
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "-u", path],
                input=stdin.encode("utf-8"),
                capture_output=True,
                cwd=workdir,
                env=env,
                timeout=TIMEOUT_SEC,
                preexec_fn=_limits if resource else None,
            )
            out, err, rc = proc.stdout, proc.stderr, proc.returncode
        except subprocess.TimeoutExpired as e:
            timed_out = True
            out, err, rc = e.stdout or b"", e.stderr or b"", -1
            err += f"\nTimeLimitExceeded: stopped after {TIMEOUT_SEC}s".encode()

        elapsed = int((time.perf_counter() - start) * 1000)

    return jsonify(
        stdout=_clip(out),
        stderr=_clip(err),
        returncode=rc,
        timed_out=timed_out,
        time_ms=elapsed,
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
