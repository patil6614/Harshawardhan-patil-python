// Runs Python in the browser with Pyodide, off the main thread.
importScripts("https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js");

let pyodidePromise = null;
function getPyodide() {
  if (!pyodidePromise) pyodidePromise = loadPyodide();
  return pyodidePromise;
}

self.onmessage = async (ev) => {
  const { code, stdin } = ev.data;
  try {
    postMessage({ type: "status", text: "loading Python…" });
    const py = await getPyodide();
    const lines = stdin.split("\n");
    let i = 0;
    py.setStdin({ stdin: () => (i < lines.length ? lines[i++] : undefined) });
    py.setStdout({ batched: (s) => postMessage({ type: "out", text: s + "\n" }) });
    py.setStderr({ batched: (s) => postMessage({ type: "err", text: s + "\n" }) });
    postMessage({ type: "status", text: "running…" });
    await py.runPythonAsync(code);
    postMessage({ type: "done", ok: true });
  } catch (e) {
    postMessage({ type: "err", text: String(e.message || e) + "\n" });
    postMessage({ type: "done", ok: false });
  }
};
