(() => {
  const DEFAULT_CODE = `# Welcome! Write Python here and press Ctrl+Enter
name = input("Your name: ")
print(f"Hello, {name}!")

for i in range(1, 6):
    print(i, "squared is", i * i)
`;

  const $ = (id) => document.getElementById(id);
  const output = $("output"), statusEl = $("status");
  const runBtn = $("run"), stopBtn = $("stop"), modeSel = $("mode");

  const editor = CodeMirror.fromTextArea($("code"), {
    mode: "python", theme: "dracula", lineNumbers: true, indentUnit: 4,
    matchBrackets: true, autoCloseBrackets: true,
    extraKeys: {
      "Ctrl-Enter": run, "Cmd-Enter": run,
      Tab: (cm) => cm.somethingSelected() ? cm.indentSelection("add") : cm.replaceSelection("    ", "end"),
    },
  });
  editor.setValue(localStorage.getItem("pycode") || DEFAULT_CODE);
  editor.on("change", () => localStorage.setItem("pycode", editor.getValue()));
  modeSel.value = localStorage.getItem("pymode") || "server";
  modeSel.onchange = () => localStorage.setItem("pymode", modeSel.value);

  let controller = null;       // fetch abort (server mode)
  let worker = null;           // Pyodide worker (browser mode)
  let running = false;

  function setRunning(v) { running = v; runBtn.disabled = v; stopBtn.disabled = !v; }
  function show(text, cls) {
    const s = document.createElement("span");
    if (cls) s.className = cls;
    s.textContent = text;
    output.appendChild(s);
  }
  function setStatus(text, cls) { statusEl.className = cls || ""; statusEl.textContent = text; }

  async function run() {
    if (running) return;
    output.textContent = "";
    setStatus("running…");
    setRunning(true);
    const code = editor.getValue(), stdin = $("stdin").value;
    try {
      if (modeSel.value === "server") await runServer(code, stdin);
      else await runBrowser(code, stdin);
    } catch (e) {
      if (e.name !== "AbortError") { show(String(e.message || e), "err"); setStatus("error", "bad"); }
    } finally { setRunning(false); }
  }

  async function runServer(code, stdin) {
    controller = new AbortController();
    const res = await fetch("/api/run", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, stdin }), signal: controller.signal,
    });
    const d = await res.json();
    if (!res.ok) { show(d.error || "Request failed", "err"); setStatus("error", "bad"); return; }
    show(d.stdout);
    if (d.stderr) show((d.stdout && !d.stdout.endsWith("\n") ? "\n" : "") + d.stderr, "err");
    const ok = d.returncode === 0;
    setStatus(`${ok ? "finished" : "exit " + d.returncode} · ${d.time_ms} ms`, ok ? "ok" : "bad");
  }

  function runBrowser(code, stdin) {
    return new Promise((resolve) => {
      worker = new Worker("/static/pyodide-worker.js");
      const t0 = performance.now();
      worker.onmessage = (ev) => {
        const m = ev.data;
        if (m.type === "status") setStatus(m.text);
        else if (m.type === "out") show(m.text);
        else if (m.type === "err") show(m.text, "err");
        else if (m.type === "done") {
          setStatus(`${m.ok ? "finished" : "error"} · ${Math.round(performance.now() - t0)} ms`, m.ok ? "ok" : "bad");
          worker.terminate(); worker = null; resolve();
        }
      };
      worker.onerror = (e) => { show(e.message, "err"); setStatus("error", "bad"); worker = null; resolve(); };
      worker.postMessage({ code, stdin });
    });
  }

  function stop() {
    if (controller) controller.abort();
    if (worker) { worker.terminate(); worker = null; }
    show("\n[stopped]", "err"); setStatus("stopped", "bad");
    setRunning(false);
  }

  runBtn.onclick = run;
  stopBtn.onclick = stop;
  $("clear").onclick = () => { output.textContent = ""; setStatus(""); };
  $("download").onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([editor.getValue()], { type: "text/x-python" }));
    a.download = "main.py"; a.click(); URL.revokeObjectURL(a.href);
  };
})();
