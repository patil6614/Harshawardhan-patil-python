# Online Python Compiler

A web-based Python editor and runner, like the online compilers you know.

- **Editor**: syntax highlighting, line numbers, auto-indent, bracket matching, Ctrl+Enter to run
- **Input box** for `input()` calls, output panel with stdout and stderr, run time, Stop, Clear, Download .py
- **Two run modes** (dropdown in the header):
  - **Server**: full Python on your server (Flask), with limits
  - **Browser**: Python runs in the visitor's browser with Pyodide, so no server risk
- Code is autosaved in the visitor's browser.

## Run locally

```bash
pip install -r requirements.txt
python app.py
# open http://localhost:5000
```

## Deploy (public)

```bash
docker build -t pycompiler .
docker run -p 5000:5000 --memory=512m --cpus=1 --pids-limit=256 \
  --read-only --tmpfs /tmp --cap-drop=ALL --network=none pycompiler
```

`--network=none` blocks user code from using the network. If you do that, put a reverse proxy
(nginx or Caddy) in front using a separate network, or publish the port with a custom bridge setup.

## Safety (important)

Running strangers' code is risky. The server mode already applies:
- separate isolated Python process (`-I`), empty environment, temporary working folder
- 10 s timeout, 256 MB memory, file size, process count and CPU limits
- 100 KB output cap, code and input size caps, 30 runs/min per IP rate limit

These limits are **not a full sandbox**. For a public site, always use the Docker setup above
(or gVisor/Firecracker), or offer only Browser mode. Never run it on a machine holding secrets.

## Files

| File | Purpose |
|---|---|
| `app.py` | Flask API: `POST /api/run` |
| `static/index.html`, `style.css`, `app.js` | The web UI |
| `static/pyodide-worker.js` | In-browser Python runner |
| `Dockerfile`, `requirements.txt` | Deployment |

## Limits to know

- Server mode: resource limits (`resource` module) work on Linux/macOS, not Windows.
- Browser mode: only pure-Python and Pyodide-supported packages; stdin is read line by line.
- Standard-library modules work in both modes. Third-party packages (numpy etc.) need to be installed on the server.
